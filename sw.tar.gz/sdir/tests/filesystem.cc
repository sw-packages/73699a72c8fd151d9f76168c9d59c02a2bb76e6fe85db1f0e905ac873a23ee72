#include <stdfwd.hh>

#include <filesystem>
#include <iostream>

void test_filesystem()
{
    //
    std::cout << "std::filesystem::current_path() = " << std::filesystem::current_path() << std::endl;
}
