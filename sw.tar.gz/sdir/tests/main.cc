#include "tests.hh"

int main()
{
    //
    test_filesystem();
}
