#include <string>
#include <vector>

#include <stdfwd.hh>

std::string inv_get_string() { return ""; }
std::vector<int> inv_get_vector() { return {1, 2, 3}; }
